/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./bin/js/contentScript.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./bin/js/contentScript.js":
/*!*********************************!*\
  !*** ./bin/js/contentScript.js ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// store the last clicked element\nlet elementObject\n// array to store all the running clickers by their ID\nlet clickers = {}\n\nfunction messageHandler(request, sender, sendResponse) {\n\tswitch (request.ID) {\n\t\tcase \"selected\":\n\t\t\tWriteNewClicker()\n\t\t\tbreak\n\n\t\tcase \"website\":\n\t\t\tsendResponse({ website: window.location.hostname })\n\t\t\tbreak\n\n\t\tcase \"restartClicker\":\n\t\t\trestartClicker(request.clicker)\n\t\t\tbreak\n\n\t\tcase \"removeClicker\":\n\t\t\tremoveClicker(request.clickerID)\n\t\t\tbreak\n\n\t\tcase \"removeClickers\":\n\t\t\tremoveClickers()\n\t\t\tbreak\n\t}\n}\n\n\n// Gets the id and xpath of an element\nfunction getElement(element) {\n\tlet id = element.id\n\tlet { relativeID, xpath } = getXPathOfElement(element)\n\treturn { id, relativeID, xpath }\n}\n\n\nfunction getXPathOfElement(el) {\n\tlet xpath = \"\"\n\t// relate from holds the id from which the xpath is relative from\n\tlet relativeID, tempEl, pos\n\n\twhile (el) {\n\t\tpos = 0\n\t\ttempEl = el\n\n\t\tif (el.id) {\n\t\t\trelativeID = el.id\n\t\t\txpath = \".\" + xpath\n\t\t\tbreak\n\t\t}\n\n\t\twhile (tempEl) {\n\t\t\tif (tempEl.nodeType === 1 && tempEl.nodeName === el.nodeName) {\n\t\t\t\tpos += 1\n\t\t\t}\n\t\t\ttempEl = tempEl.previousSibling\n\t\t}\n\n\n\t\txpath = \"/\" + el.tagName.toLowerCase() + \"[\" + pos + \"]\" + xpath\n\t\tel = el.parentElement\n\t}\n\treturn { relativeID, xpath }\n}\n\n// MDN snippet for evaluating an xpath expresion and returning it's founds\nfunction evaluateXPath(aNode, aExpr) {\n\tvar xpe = new XPathEvaluator();\n\tvar nsResolver = xpe.createNSResolver(aNode.ownerDocument == null ?\n\t\taNode.documentElement : aNode.ownerDocument.documentElement);\n\tvar result = xpe.evaluate(aExpr, aNode, nsResolver, 0, null);\n\tvar found = [];\n\tvar res;\n\twhile (res = result.iterateNext())\n\t\tfound.push(res);\n\treturn found;\n}\n\n\n// FIXME: rename this function to something comprehensive\nfunction getClickers() {\n\tbrowser.storage.local.get([window.location.hostname], clickerObjectJSON => {\n\t\tif (clickerObjectJSON[window.location.hostname]) {\n\t\t\tlet clickerObject = JSON.parse(clickerObjectJSON[window.location.hostname])\n\t\t\tfor (let [clickerNr, clicker] of Object.entries(clickerObject)) {\n\t\t\t\tif (clicker.active) {\n\t\t\t\t\tstartClicker(clickerNr, clicker)\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t})\n}\n\n\nfunction generateNewClickerID(currentIDs, length) {\n\twhile (true) {\n\t\tlet generated = '';\n\t\tlet characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';\n\t\tlet charactersLength = characters.length;\n\t\tfor (var i = 0; i < length; i++) {\n\t\t\tgenerated = generated + characters.charAt(Math.floor(Math.random() * charactersLength));\n\t\t}\n\n\t\tif (currentIDs.indexOf(generated) == -1) {\n\t\t\treturn generated\n\t\t}\n\t}\n}\n\n\nfunction restartClicker(clicker) {\n\tlet clickerID = Object.keys(clicker)[0]\n\tclearInterval(clickers[clickerID])\n\tstartClicker(clickerID, clicker[clickerID])\n}\n\nfunction removeClickers() {\n\tfor (let [clickerNr, clicker] of Object.entries(clickers)) {\n\t\tremoveClicker(clickerNr)\n\t}\n}\n\n\nfunction removeClicker(clickerID) {\n\tclearInterval(clickers[clickerID])\n}\n\n// Find the element that needs to be clicked\n// creates a new entry in the clickers list\nfunction startClicker(clickerID, clickerObject) {\n\tlet elementToClick\n\n\tif (clickerObject.active) {\n\t\tlet interval = clickerObject.interval\n\t\tif (clickerObject.intervalStep == \"s\") {\n\t\t\tinterval *= 1000\n\t\t}\n\t\tif (clickerObject.elemID) {\n\t\t\telementToClick = document.getElementById(clickerObject.elemID)\n\t\t} else {\n\t\t\tlet xpathObjects = evaluateXPath(clickerObject.relativeID ? document.getElementById(clickerObject.relativeID) : document, clickerObject.xpath)\n\n\n\t\t\t//TODO: more than 1 xpath handling\n\t\t\tif (xpathObjects.length > 1) {\n\t\t\t\telementToClick = xpathObjects[0]\n\n\t\t\t} else {\n\t\t\t\tconsole.log(\"xpath found more that 1 object\")\n\t\t\t}\n\t\t}\n\t\tif (elementToClick) {\n\t\t\tclickers[clickerID] = (setInterval(() => elementToClick.click(), parseInt(interval)))\n\t\t}\n\t}\n}\n\n\n// Create a new clicker object in the local.storage\n// of there isn't already one with the same ID or xpath \n// Since the storage is stored based on the sites URI (to avoid dynamic links...)\n// If there is an Item with the same ID or xpath it will be considered as 1\n// Don't know what kind of effect it will have on the usability, but I think very minimal\nfunction WriteNewClicker(message) {\n\tlet { id, relativeID, xpath } = getElement(elementObject)\n\tlet currentClickerIDlist = []\n\tlet newClicker = {\n\t\t\"elemID\": id,\n\t\t\"name\": id ? id : relativeID,\n\t\t\"relativeID\": relativeID,\n\t\t\"xpath\": xpath,\n\t\t\"interval\": 1,\n\t\t\"intervalStep\": \"s\",\n\t\t\"active\": false\n\t}\n\n\tbrowser.storage.local.get(window.location.hostname, response => {\n\t\tif (response[window.location.hostname]) {\n\t\t\tlet responseValue = JSON.parse(response[window.location.hostname])\n\n\n\t\t\t// If there is already an elemen with the same ID or xpath don't generate\n\t\t\t// a new item\n\t\t\tfor (let [itemNr, item] of Object.entries(responseValue)) {\n\t\t\t\tcurrentClickerIDlist.push(itemNr)\n\t\t\t\tif ((item[\"elemID\"] == newClicker[\"elemID\"] && newClicker[\"elemID\"] != \"\")\n\t\t\t\t\t|| ((item[\"xpath\"] == newClicker[\"xpath\"] && newClicker['xpath'] != \"\") &&\n\t\t\t\t\t\titem[\"relativeID\"] == newClicker[\"relativeID\"] && newClicker[\"relativeID\"] != \"\")) {\n\t\t\t\t\treturn\n\t\t\t\t}\n\t\t\t}\n\n\t\t\t// Generate a unique ID for the clickerID\n\t\t\t// Used for deleting, restarting the clicker without reseting everyhting\n\t\t\tlet clickerID = generateNewClickerID(currentClickerIDlist, 5)\n\t\t\t// If there are no duplicates add the new item to the list\n\t\t\tresponseValue[clickerID] = newClicker\n\t\t\tbrowser.storage.local.set({ [window.location.hostname]: JSON.stringify(responseValue) })\n\n\t\t} else {\n\t\t\tlet clickerID = generateNewClickerID(currentClickerIDlist, 5)\n\t\t\tbrowser.storage.local.set({ [window.location.hostname]: JSON.stringify({ [clickerID]: newClicker }) })\n\t\t}\n\t})\n}\n\ndocument.addEventListener(\"mousedown\", event => elementObject = event.target);\nbrowser.runtime.onMessage.addListener(messageHandler)\ngetClickers()\n\n//# sourceURL=webpack:///./bin/js/contentScript.js?");

/***/ })

/******/ });
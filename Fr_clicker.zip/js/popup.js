/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./bin/js/popup.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./bin/js/popup.js":
/*!*************************!*\
  !*** ./bin/js/popup.js ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("const itemList = document.getElementById(\"listOfItems\")\nconst position = \"beforeend\"\nlet website \nlet helpMessage = \"<p class='helpMessage'>Right click on an element and select <br/>'Send Element to Clicker'</p>\"\nlet unavailableMessage = \"<p class='helpMessage'>Sorry we only work with http sites, if that bothers you please leave feadback ;), so we can improve the extension <br/> <b>Try reloading the page</b></p>\"\n\n\nfunction onError(err){\n    console.log(\"Error: \" + err)\n}\n\n// To all the loaded items add listeners to all their buttons\nfunction AddListeners(){\n    for (let element of itemList.getElementsByClassName(\"clickItem\")){\n        // Delete button\n        element.getElementsByClassName(\"deleteButton\")[0].\n            addEventListener(\"click\", click => deleteItem(click.target))\n        \n        // Interval\n        element.getElementsByClassName(\"interval\")[0].\n            addEventListener(\"blur\", changedEvent => changeInterval(changedEvent))\n\n        element.getElementsByClassName(\"intervalDropDown\")[0].\n            addEventListener(\"change\", changedEvent => changeIntervalStep(changedEvent))\n\n        element.getElementsByClassName(\"itemClassifier\")[0].\n            addEventListener(\"blur\" ,changedEvent => changeItemClassifier(changedEvent))\n\n        element.getElementsByClassName(\"startStop\")[0].\n            addEventListener(\"click\", activationEvent => switchClicker(activationEvent))\n    }\n}\n\n\nfunction changeInterval(changedEvent){\n    let elemID = getClickItemID(changedEvent.target)\n    let intervalValue = changedEvent.target.innerHTML.trim()\n    let newValue = \"\" \n\n    for (let [charnr, char] of Object.entries(intervalValue)){\n        if(\"0123456789\".indexOf(char) !== -1){\n            newValue += char\n        } \n        changedEvent.target.innerHTML = newValue\n    }\n\n    writeChange({interval: parseInt(newValue)}, elemID)\n}\n\nfunction changeIntervalStep(changeEvent){\n    let elemID = getClickItemID(changeEvent.target)\n    writeChange({intervalStep: changeEvent.target.value}, elemID)\n}\n\nfunction changeItemClassifier(changedEvent){\n    let elemID = getClickItemID(changedEvent.target)\n    writeChange({name: changedEvent.target.innerHTML}, elemID)\n}\n\n// change = {key, value} of clicker\nfunction writeChange(change, elemID){\n\n    browser.storage.local.get(website, websiteData =>{\n        let dataObject = JSON.parse(websiteData[website])\n        dataObject[elemID][Object.keys(change)[0]] = change[Object.keys(change)[0]]\n        let clicker = {[elemID]: dataObject[elemID]}\n        browser.storage.local.set({[website]: JSON.stringify(dataObject)}, () => restartClicker(clicker))\n      })\n}\n\n\nfunction switchClicker(activationEvent){\n    let elemID = getClickItemID(activationEvent.target)\n    \n    // If clicker is turned off\n    if(activationEvent.target.className.indexOf(\"Active\") == -1){\n        writeChange({active: true}, elemID)\n        activationEvent.target.className += \" Active\"\n    } else {\n        writeChange({active: false}, elemID)\n        activationEvent.target.className = activationEvent.target.className.replace(\"Active\", \"\")\n    }\n}\n\n\nfunction getClickItemID(target){\n    let element = target.parentElement\n    console.log(element)\n    console.log(target)\n    while (true){\n        if(element.classList[0] == \"clickItem\"){\n            return element.classList[element.classList.length - 1]\n            }\n        element = element.parentElement    \n    }\n}\n\n\nfunction loadItems(){\n    let added = false\n    browser.tabs.query({currentWindow: true, active: true}, (tabs) => {\n        browser.tabs.sendMessage(tabs[0].id, {\"ID\": \"website\"}, webResp => {\n            if(webResp){\n                website = webResp.website\n            browser.storage.local.get(website, itemData => {\n                if(itemData[website]){\n                let content = JSON.parse(itemData[website])\n                for (let [itemNr, item] of Object.entries(content)){\n                    let clickerItem = `<div class=\"clickItem ${itemNr}\">\n                    <div class='clickItemContainer'>\n                    <div class=\"startStop elevatingInput ${item.active? \"Active\" : \"\"}\" >\n                        <div class=\"buttonSizer ${item.active? \"Active\" : \"\"}\"></div>\n                    </div>\n                    <div contentEditable autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\"\n                        spellcheck=\"false\" class=\"itemClassifier elevatingInput\">${item.name? item.name: \"Unnamed\"}</div>\n                    \n                    <div class=\"intervalHolder\">\n                        <span>Int:</span>\n                        <div contentEditable class=\"interval elevatingInput\">\n                        ${item.interval}\n                        </div>\n                        <select class=\"intervalDropDown\">\n                            <option ${item.intervalStep == \"ms\"? \"Selected='selected'\":\"\"} value=\"ms\">ms</option>\n                            <option ${item.intervalStep == \"s\"? \"Selected='selected'\":\"\"} value=\"s\">s</option>\n                    </select>\n                    </div>\n                    <div class=\"deleteButton elevatingInput\"/>\n                    </div>\n                    </div>`\n                    \n                    // let eToInsert = document.createElement(\"div\")\n                    // eToInsert.innerHTML = clickerItem\n                    // itemList.appendChild(eToInsert)\n                    itemList.insertAdjacentHTML(position, clickerItem)\n                    added = true\n                    }\n                    AddListeners()    \n                }\n            if (!added){\n                itemList.parentElement.insertAdjacentHTML(position, helpMessage)\n                added = true\n            }\n            })\n            } else {\n                itemList.parentElement.insertAdjacentHTML(position, unavailableMessage)\n                } \n            }\n        )\n    })\n}\n\n\n// [DELETE]\n// Deletes an item by it's id from local storage\n// stored in websites name\nfunction deleteItem(elementToDelete){\n    console.log(\"removing item\")\n    let deleteID = getClickItemID(elementToDelete)\n    browser.storage.local.get(website, websiteItems =>{\n        let items = JSON.parse(websiteItems[website])\n        let clicker = items[deleteID]\n        delete items[deleteID]\n        browser.storage.local.set({[website]: JSON.stringify(items)}, () => {\n            removeSignalContentScript(deleteID)\n            \n            for(let [nr, child] of Object.entries(itemList.childNodes)){\n                if(child.tagName == \"DIV\"){\n                    if (child.classList[child.classList.length -1] == deleteID)\n                        itemList.removeChild(child)\n                    }\n            }\n            \n            // if there are no more clickers, rerun the load command to print the help message\n            if(itemList.childNodes.length == 1){\n                loadItems()\n            }\n        })\n    })\n} \n\nfunction restartClicker(clicker){\n    browser.tabs.query({currentWindow: true, active: true }, tabsList => {\n    browser.tabs.sendMessage(tabsList[0].id, {\"ID\": \"restartClicker\", \"clicker\": clicker})\n    })\n}\n\nfunction removeSignalContentScript(deleteID){\n    browser.tabs.query({currentWindow: true, active: true }, tabsList => {\n        browser.tabs.sendMessage(tabsList[0].id, {\"ID\": \"removeClicker\", \"clickerID\": deleteID})\n        })\n}\n\n\n\nwindow.addEventListener(\"load\", loadItems)\n\n\n//# sourceURL=webpack:///./bin/js/popup.js?");

/***/ })

/******/ });